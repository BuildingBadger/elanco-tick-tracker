from django.urls import path

from .views import SightingListCreateView


urlpatterns = [
    path("sightings/", SightingListCreateView.as_view(), name="sighting-list-create"),
]

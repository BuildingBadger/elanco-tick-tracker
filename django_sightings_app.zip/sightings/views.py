from datetime import datetime

from django.db.models import Q
from rest_framework import generics
from rest_framework.parsers import FormParser, JSONParser, MultiPartParser

from .models import Sighting
from .serializers import SightingSerializer


class SightingListCreateView(generics.ListCreateAPIView):
    serializer_class = SightingSerializer
    parser_classes = [JSONParser, FormParser, MultiPartParser]

    def get_queryset(self):
        queryset = Sighting.objects.all()
        params = self.request.query_params

        if params.get("from"):
            queryset = queryset.filter(sighting_at__date__gte=params["from"])
        if params.get("to"):
            queryset = queryset.filter(sighting_at__date__lte=params["to"])
        if params.get("species"):
            queryset = queryset.filter(species__iexact=params["species"])
        if params.get("location"):
            queryset = queryset.filter(location__icontains=params["location"])

        bounds = {
            "latitude__gte": params.get("min_lat"),
            "latitude__lte": params.get("max_lat"),
            "longitude__gte": params.get("min_lng"),
            "longitude__lte": params.get("max_lng"),
        }
        return queryset.filter(**{key: value for key, value in bounds.items() if value})

    def perform_create(self, serializer):
        serializer.save(source="user")
